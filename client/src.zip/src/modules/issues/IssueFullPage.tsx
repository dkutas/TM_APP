export default function IssueFullPage() {
    return <></>
}