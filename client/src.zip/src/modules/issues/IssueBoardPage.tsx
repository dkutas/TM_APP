export default function IssueBoardPage() {
    return <></>

}