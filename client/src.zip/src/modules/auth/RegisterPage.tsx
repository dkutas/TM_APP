export default function RegisterPage() {
    return <></>

}